book = {"apple": 0.67, "milk": 1.49, "avocado": 1.49}
print(book)
