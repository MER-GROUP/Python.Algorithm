# Grokking-Algorithms: An Illustrated Guide for Programmers and Other Curious People by Aditya Bhargava

:hugs: Meet the author [Aditya Bhargava](https://adit.io/)

:eyes: [Official repository](https://github.com/egonSchiele/grokking_algorithms)

:books: Discover the book in [English](https://www.amazon.com/gp/product/1617292230/ref=as_li_tl?ie=UTF8&tag=adit074-20&camp=1789&creative=9325&linkCode=as2&creativeASIN=1617292230&linkId=8e53f7c690634522f34ef6aca879bc34) and [Portuguese](https://www.amazon.com.br/Entendendo-Algoritmos-Ilustrado-Programadores-Curiosos/dp/8575225634/ref=sr_1_1?keywords=entendendo+algoritmos&qid=1650410104&sprefix=enten%2Caps%2C507&sr=8-1)

***

This repository is dedicated to the codes of the book and they are written in Python 3.10.
